import React, { useState } from "react";
import { observer } from "mobx-react-lite";
import { store } from "../store";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";

const FormContainer = styled.div`
  max-width: 400px;
  margin: 20px auto;
  padding: 20px;
  border-radius: 10px;
`;

const H2 = styled.h2`
  color: #ff8989;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 2px solid #ff8989;
  border-radius: 5px;
  font-size: 16px;
  box-sizing: border-box;
  outline: none;
`;

const Button = styled.button`
  width: 100%;
  padding: 10px;
  background-color: #89AC46;
  color: white;
  border: none;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;

  &:hover {
    background-color: #77a033;
  }
`;

const Upload = observer(() => {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
    image: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

 
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        setFormData({ ...formData, image: reader.result });
      };
    }
  };

 
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.title || !formData.description || !formData.price || !formData.image) {
      alert("All fields are required!");
      return;
    }

    const newImage = {
      id: Date.now(), 
      ...formData,
    };

   
    const storedImages = JSON.parse(localStorage.getItem("images")) || [];
    const exists = storedImages.find((img) => img.title === newImage.title);

    if (!exists) {
      store.addImage(newImage);
      localStorage.setItem("images", JSON.stringify([ ...storedImages, newImage]));

    }

    setFormData({ title: "", description: "", price: "", image: "" });
    navigate("/gallery");
  };

  return (
    <FormContainer>
      <H2>Upload Image</H2>
      <form onSubmit={handleSubmit}>
        <Input type="text" name="title" placeholder="Title" value={formData.title} onChange={handleChange} />
        <Input type="text" name="description" placeholder="Description" value={formData.description} onChange={handleChange} />
        <Input type="text" name="price" placeholder="Price" value={formData.price} onChange={handleChange} />
        <Input type="file" accept="image/*" onChange={handleImageChange} />
        <Button type="submit">Upload</Button>
      </form>
    </FormContainer>
  );
});

export default Upload;
