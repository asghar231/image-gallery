import React from "react";
import { observer } from "mobx-react-lite";
import { store } from "../store";
import styled from "styled-components";
import { FaHeart } from "react-icons/fa"; // Filled heart icon

const FavouritesContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  padding: 20px;
  justify-content: center;
`;

const Card = styled.div`
  background: white;
  padding: 10px;
  width: 280px;
  border: solid 2px rgb(185, 170, 118);
  text-align: center;
  border-radius: 10px;
  position: relative;
`;

const ImageContainer = styled.div`
  position: relative;
  width: 100%;
`;

const Image = styled.img`
  width: 100%;
  height: 160px;
  object-fit: cover;
  border-radius: 10px;
`;

const HeartIcon = styled(FaHeart)`
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 20px;
  color: #ff8989;
  cursor: pointer;
`;

const InfoContainer = styled.div`
  padding: 10px;
  text-align: left;
`;

const TitlePriceContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 16px;
  font-weight: bold;
  color: #ff8989;
`;

const Description = styled.p`
  font-size: 14px;
  color: #777;
  margin-top: 10px;
  margin-bottom: 0px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const Favourites = observer(() => {
  const favouriteImages = store.images.filter((image) => image.isFavourite);

  return (
    <FavouritesContainer>
      {favouriteImages.length === 0 ? (
        <p>No favourite images yet.</p>
      ) : (
        favouriteImages.map((image) => (
          <Card key={image.id}>
            <ImageContainer>
              <Image src={image.image} alt={image.title} />
              {/* Heart Icon to remove from favourites */}
              <HeartIcon onClick={() => store.toggleFavourite(image.id)} />
            </ImageContainer>
            <InfoContainer>
              <TitlePriceContainer>
                <span>{image.title}</span>
                <span>${image.price}</span>
              </TitlePriceContainer>
              <Description>{image.description}</Description>
            </InfoContainer>
          </Card>
        ))
      )}
    </FavouritesContainer>
  );
});

export default Favourites;
