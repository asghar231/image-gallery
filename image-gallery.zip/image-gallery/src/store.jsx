import { types } from "mobx-state-tree";


const ImageModel = types.model({
  id: types.identifierNumber,
  title: types.string,
  description: types.string,
  price: types.string,
  image: types.string,  
  isFavourite: types.optional(types.boolean, false)
});


export const ImageStore = types
  .model({
    images: types.array(ImageModel),
    favourites: types.array(ImageModel)
  })
  .actions((self) => ({
    addImage(image) {
      self.images.unshift(image);
      this.saveToLocalStorage();
    },

    toggleFavourite(id){
      const image = self.images.find(img => img.id === id);
      if (image) {
        image.isFavourite = !image.isFavourite;
        store.saveToLocalStorage();
      }
    },
    // removeImage(id) {
    //   self.images = self.images.filter(image => image.id !== id);
    //   this.saveToLocalStorage();
    // },

    saveToLocalStorage() {
      localStorage.setItem("images", JSON.stringify(self.images));
    },

    loadFromLocalStorage() {
      const storedImages = JSON.parse(localStorage.getItem("images")) || [];
      self.images = storedImages;
    }
  }));


export const store = ImageStore.create({ images: [] });


store.loadFromLocalStorage();
