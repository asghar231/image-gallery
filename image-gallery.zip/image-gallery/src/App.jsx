// import { createBrowserRouter, RouterProvider } from "react-router-dom"
// import AppLayout from "./layout/AppLayout"
// import  Gallery  from "./pages/Gallery"
// import  Upload  from "./pages/Upload"
// import { Favourites } from "./pages/Favourites"




// const App = () => {

//   const router = createBrowserRouter([

//     {
//       path: '/',
//       element: <AppLayout />,
//       // errorElement: <ErrorPage />,
//       children: [
//         {
//           path: '/gallery',
//           element: <Gallery />
//         },
//         {
//           path: '/upload',
//           element: <Upload />
//         },
//         // {
//         //   path: '/contact',
//         //   element: <Favourites />,
//         //   action: contactData
//         // },
//       ]
//     },
  
// ])


import { createBrowserRouter, RouterProvider } from "react-router-dom";
import AppLayout from "./layout/AppLayout";
import Gallery from "./pages/Gallery";
import Upload from "./pages/Upload";
import Favourite from "./pages/Favourite"

const router = createBrowserRouter([
  {
    path: "/",
    element: <AppLayout />,
    children: [
      {
        path: "gallery",
        element: <Gallery />,
      },
      {
        path: "upload",
        element: <Upload />,
      },
      {
        path: "favourite",
        element: <Favourite />,
      },
    ],
  },
]);

const App = () => {
  return <RouterProvider router={router} />;
};

export default App;
