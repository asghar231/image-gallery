import React from "react";
import styled from "styled-components";
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from "react-icons/fa";

const FooterContainer = styled.footer`
  width: 100%;
  max-width: 100vw; 
  background: #89AC46; 
  color: white;
  padding: 1.5rem 2rem;
  text-align: center;
  border-radius: 10px;
  position: relative;
  bottom: 0;
  box-sizing: border-box;
`;


const SocialIcons = styled.div`
  margin-top: 1rem;

  a {
    color: white;
    margin: 0 0.5rem;
    font-size: 1.5rem;
    transition: color 0.3s ease-in-out;

    &:hover {
      color: #FF8989; /* Light green hover effect */
    }
  }
`;

export const Footer = () => {
  return (
    <FooterContainer>
    
      <SocialIcons>
        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><FaFacebook /></a>
        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer"><FaTwitter /></a>
        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"><FaInstagram /></a>
        <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"><FaLinkedin /></a>
      </SocialIcons>
      <p>&copy; {new Date().getFullYear()} Image Gallery | All Rights Reserved</p>
    </FooterContainer>
  );
};


