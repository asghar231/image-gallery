import React from "react";
import styled from "styled-components";
import { Link } from "react-router-dom";

const HeroContainer = styled.section`
  width: 100%;
 box-sizing: border-box;
  height: 60vh;  /* Adjust height as needed */
  background: url("https://media.istockphoto.com/id/517188688/photo/mountain-landscape.jpg?s=1024x1024&w=0&k=20&c=z8_rWaI8x4zApNEEG9DnWlGXyDIXe-OmsAyQ5fGPVV8=") no-repeat center/cover; 
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  color: white;
  // padding: 2rem;
  position: relative;
  border-radius: 10px;
  margin-top: 2px;
`;

const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5); /* Dark overlay for better text visibility */
  border-radius: 10px;
`;

const HeroContent = styled.div`
  position: relative;
  z-index: 2;
  max-width: 800px;
`;

const Title = styled.h1`
  font-size: 3rem;
  margin-bottom: 1rem;
`;

const Subtitle = styled.p`
  font-size: 1.2rem;
  margin-bottom: 1.5rem;
`;

const UploadButton = styled(Link)`
  display: inline-block;
  background: #ff8989;
  color: white;
  padding: 0.8rem 1.5rem;
  font-size: 1rem;
  text-decoration: none;
  border-radius: 8px;
  transition: 0.3s ease-in-out;

  &:hover {
    background: #ff5757;
  }
`;

const HeroSection = () => {
  return (
    <HeroContainer>
      <Overlay />
      <HeroContent>
        <Title>Welcome to the world of Glory</Title>
        <Subtitle>Explore amazing pictures or upload your own to share with the world!</Subtitle>
        <UploadButton to="/upload">Upload Image</UploadButton>
      </HeroContent>
    </HeroContainer>
  );
};

export default HeroSection;
