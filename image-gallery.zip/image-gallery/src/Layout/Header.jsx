import React from "react";
import styled from "styled-components";
import { Link } from "react-router-dom";  

const HeaderContainer = styled.header`
  width: 100%;  /* Fixed width issue */
  background: #89AC46;
  color: white;
  padding: 0 16px;  
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 10px;
  box-sizing: border-box;
`;

const Logo = styled.h1`
  font-size: 1.5rem;
  color:rgb(248, 187, 187);
`;



const Nav = styled.nav`
ul {
  list-style: none;
  display: flex;
  gap: 1.5rem;
  padding: 0;
  margin: 0;
}

li {
  font-size: 1.2rem;
}

a {
  text-decoration: none;
  color: white;
  transition: color 0.3s ease-in-out;

  &:hover {
    color: #ff8989; /* Now hover will work */
  }
}
`;


export const Header = () => {
  return (
    <HeaderContainer>
      <Logo>Image Gallery</Logo>
      <Nav>
        <ul>
          <li><Link to="/gallery">Gallery</Link></li>
          <li><Link to="/upload">Upload</Link></li>
          <li><Link to="/favourite">Favourites</Link></li>
        </ul>
      </Nav>
    </HeaderContainer>
  );
};
